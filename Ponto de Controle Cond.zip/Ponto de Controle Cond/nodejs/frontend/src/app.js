/**
 * app.js — Lógica do frontend CondoGest (versão profissional)
 */

const API = 'http://localhost:3000/api';
let tipoSelecionado = 'padrao';

// ── Init ───────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Verifica se o usuário está logado
  try {
    const resp = await fetch('/api/auth/me', { credentials: 'same-origin' });
    if (!resp.ok) { window.location.href = '/login'; return; }
    const user = await resp.json();
    document.getElementById('userName').textContent  = user.nome || user.usuario;
    document.getElementById('userAvatar').textContent = (user.nome || user.usuario)[0].toUpperCase();
  } catch {
    window.location.href = '/login';
    return;
  }

  atualizarHeader();

  ['area', 'metrosFrente', 'temGaragem'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', atualizarPreview);
  });

  // Preenche senha padrão com número do imóvel quando digitado
  document.getElementById('numero')?.addEventListener('input', () => {
    const num = document.getElementById('numero').value.trim();
    const senhaEl = document.getElementById('senhaMorador');
    if (senhaEl && !senhaEl.dataset.dirty) senhaEl.value = num;
  });
  document.getElementById('senhaMorador')?.addEventListener('input', function() {
    this.dataset.dirty = 'true';
  });
});

// ── Sugerir Login e Gerar Senha ──────────────────────────
function sugerirLogin() {
  const cpf      = document.getElementById('cpf').value.replace(/\D/g, '');
  const loginEl  = document.getElementById('loginMorador');
  if (loginEl && !loginEl.dataset.dirty) loginEl.value = cpf;
}

function gerarSenha() {
  const chars  = 'abcdefghjkmnpqrstuvwxyz23456789';
  const senha  = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  const senhaEl = document.getElementById('senhaMorador');
  senhaEl.value = senha;
  senhaEl.dataset.dirty = 'true';
  senhaEl.focus();
}

// Marca login como manually edited
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loginMorador')?.addEventListener('input', function() {
    this.dataset.dirty = 'true';
  });
});

// ── Navegação ─────────────────────────────────────
function trocarView(nome, linkEl) {
  // Atualiza view ativa
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById('view' + capitalize(nome)).classList.add('active');

  // Atualiza nav
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  if (linkEl) linkEl.classList.add('active');
  else {
    const match = document.querySelector(`.nav-item[data-view="${nome}"]`);
    if (match) match.classList.add('active');
  }

  // Títulos
  const titles = {
    dashboard: ['Painel', 'Visão geral do condomínio'],
    imoveis:   ['Imóveis', 'Lista completa de imóveis cadastrados'],
    cadastrar: ['Cadastrar', 'Novo imóvel'],
  };
  const [title, sub] = titles[nome] || ['', ''];
  document.getElementById('pageTitle').textContent = title;
  document.getElementById('pageBreadcrumb').textContent = sub;

  if (nome === 'dashboard') carregarDashboard();
  if (nome === 'imoveis')   carregarImoveis();
  return false;
}

function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ── Tipo de casa ──────────────────────────────────
function selecionarTipo(tipo) {
  tipoSelecionado = tipo;
  document.getElementById('btnPadrao').classList.toggle('active', tipo === 'padrao');
  document.getElementById('btnEsquina').classList.toggle('active', tipo === 'esquina');

  document.querySelectorAll('.esquina-field').forEach(el => {
    el.style.display = tipo === 'esquina' ? 'flex' : 'none';
  });
  document.querySelectorAll('.padrao-field').forEach(el => {
    el.style.display = tipo === 'padrao' ? 'flex' : 'none';
  });

  document.getElementById('ruaSecundaria').required = tipo === 'esquina';
  document.getElementById('metrosFrente').required   = tipo === 'esquina';

  atualizarPreview();
}

// ── Preview de taxa ───────────────────────────────
function atualizarPreview() {
  const area = parseFloat(document.getElementById('area').value) || 0;
  let taxa = 0;

  if (tipoSelecionado === 'padrao') {
    const garagem = document.getElementById('temGaragem').checked;
    taxa = 200 + area * 5 + (garagem ? 50 : 0);
  } else {
    const metros = parseFloat(document.getElementById('metrosFrente').value) || 0;
    taxa = 300 + area * 7.5 + metros * 3;
  }

  document.getElementById('taxaPreview').textContent = brl(taxa);
}

// ── Cadastrar ─────────────────────────────────────
async function cadastrar(e) {
  e.preventDefault();
  setLoading(true);

  try {
    const isPadrao = tipoSelecionado === 'padrao';
    const url  = isPadrao ? `${API}/casas/padrao` : `${API}/casas/esquina`;
    const body = {
      numero:       parseInt(document.getElementById('numero').value),
      rua:          document.getElementById('rua').value.trim(),
      area:         parseFloat(document.getElementById('area').value),
      nomeMorador:  document.getElementById('nomeMorador').value.trim(),
      cpf:          document.getElementById('cpf').value.trim(),
      telefone:     document.getElementById('telefone').value.trim(),
      loginMorador: document.getElementById('loginMorador').value.trim(),
      senhaMorador: document.getElementById('senhaMorador').value,
      ...(isPadrao
        ? { temGaragem: document.getElementById('temGaragem').checked }
        : {
            ruaSecundaria: document.getElementById('ruaSecundaria').value.trim(),
            metrosFrente:  parseFloat(document.getElementById('metrosFrente').value),
          }),
    };

    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const data = await resp.json();

    if (!resp.ok) {
      toast(data.erro || 'Erro ao cadastrar.', 'error');
    } else {
      resetarForm();
      atualizarHeader();
      // Exibe modal com credenciais criadas
      exibirModal(
        data.loginMorador?.usuario || body.loginMorador,
        data.loginMorador?.senha   || body.senhaMorador,
        data.taxa
      );
    }
  } catch {
    toast('Não foi possível conectar ao servidor.', 'error');
  } finally {
    setLoading(false);
  }
}

function setLoading(on) {
  const btn = document.getElementById('btnSubmit');
  document.getElementById('btnText').style.display    = on ? 'none' : '';
  document.getElementById('btnLoading').style.display = on ? '' : 'none';
  btn.disabled = on;
}

function resetarForm() {
  document.getElementById('formCadastro').reset();
  // Limpa flags de edição manual
  const loginEl = document.getElementById('loginMorador');
  const senhaEl = document.getElementById('senhaMorador');
  if (loginEl) { loginEl.value = ''; delete loginEl.dataset.dirty; }
  if (senhaEl) { senhaEl.value = ''; delete senhaEl.dataset.dirty; }
  atualizarPreview();
}

// ── Modal de credenciais ────────────────────────────────
function exibirModal(login, senha, taxa) {
  document.getElementById('modalLogin').textContent = login || '?';
  document.getElementById('modalSenha').textContent = senha || '?';
  document.getElementById('modalTaxa').textContent  = brl(taxa);
  document.getElementById('modalOverlay').style.display = 'flex';
}

function fecharModal() {
  document.getElementById('modalOverlay').style.display = 'none';
}

// ── Dashboard ─────────────────────────────────────
async function carregarDashboard() {
  try {
    const [resImoveis, resSaldo] = await Promise.all([
      fetch(`${API}/imoveis`),
      fetch(`${API}/saldo`),
    ]);
    const { imoveis } = await resImoveis.json();
    const saldo = await resSaldo.json();

    const padrao  = imoveis.filter(i => i.tipo === 'Casa Padrão').length;
    const esquina = imoveis.filter(i => i.tipo === 'Casa de Esquina').length;

    document.getElementById('kpiTotal').textContent   = imoveis.length;
    document.getElementById('kpiPadrao').textContent  = padrao;
    document.getElementById('kpiEsquina').textContent = esquina;
    document.getElementById('kpiSaldo').textContent   = brl(saldo.saldo);

    const tbody = document.getElementById('dashTableBody');
    if (imoveis.length === 0) {
      tbody.innerHTML = '<tr class="table-empty"><td colspan="6">Nenhum imóvel cadastrado.</td></tr>';
      return;
    }

    // Mostra os últimos 5
    const recentes = [...imoveis].slice(-5).reverse();
    tbody.innerHTML = recentes.map(i => `
      <tr>
        <td><strong>#${i.numero}</strong></td>
        <td>${badgeTipo(i.tipo)}</td>
        <td style="color:var(--text-secondary)">${i.rua}</td>
        <td style="color:var(--text-secondary)">${i.area} m²</td>
        <td style="color:var(--text-secondary)">${i.morador}</td>
        <td class="text-right taxa-cell">${brl(i.taxa)}</td>
      </tr>`).join('');
  } catch {
    /* silencioso */
  }
}

// ── Listar imóveis ────────────────────────────────
async function carregarImoveis() {
  const tbody = document.getElementById('imoveisTableBody');
  tbody.innerHTML = '<tr class="table-empty"><td colspan="7">Carregando...</td></tr>';

  try {
    const resp = await fetch(`${API}/imoveis`);
    const { imoveis } = await resp.json();

    if (imoveis.length === 0) {
      tbody.innerHTML = '<tr class="table-empty"><td colspan="7">Nenhum imóvel cadastrado.</td></tr>';
      return;
    }

    tbody.innerHTML = imoveis.map(i => `
      <tr>
        <td><strong>#${i.numero}</strong></td>
        <td>${badgeTipo(i.tipo)}</td>
        <td style="color:var(--text-secondary)">${i.rua}</td>
        <td style="color:var(--text-secondary)">${i.area} m²</td>
        <td style="color:var(--text-secondary)">${extraInfo(i)}</td>
        <td style="color:var(--text-secondary);font-size:12px">${i.morador}</td>
        <td class="text-right taxa-cell">${brl(i.taxa)}</td>
      </tr>`).join('');
  } catch {
    tbody.innerHTML = '<tr class="table-empty"><td colspan="7">Erro ao carregar.</td></tr>';
  }
}

// ── Header stats ──────────────────────────────────
async function atualizarHeader() {
  try {
    const resp = await fetch(`${API}/saldo`);
    const data = await resp.json();
    document.getElementById('hdrImoveis').textContent = data.totalImoveis;
    document.getElementById('hdrSaldo').textContent   = brl(data.saldo);
  } catch { /* silencioso */ }
}

// ── Logout ────────────────────────────────────────────
async function fazerLogout() {
  await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
  window.location.href = '/login';
}

// ── Utilitários ──────────────────────────────────────
function brl(valor) {
  return (valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function badgeTipo(tipo) {
  return tipo === 'Casa Padrão'
    ? '<span class="badge badge-blue">Padrão</span>'
    : '<span class="badge badge-amber">Esquina</span>';
}

function extraInfo(i) {
  if (i.tipo === 'Casa Padrão')
    return i.temGaragem ? '🚗 Com garagem' : 'Sem garagem';
  return `${i.metrosFrente}m frente`;
}

let toastTimer;
function toast(msg, tipo = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${tipo} show`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 4000);
}

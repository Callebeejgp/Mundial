/**
 * login.js — Lógica da página de login com seleção de perfil
 */

let perfilSelecionado = 'admin';

function selecionarPerfil(perfil) {
  perfilSelecionado = perfil;

  document.getElementById('roleAdmin').classList.toggle('active',   perfil === 'admin');
  document.getElementById('roleMorador').classList.toggle('active', perfil === 'morador');

  const labelUsuario = document.getElementById('labelUsuario');
  const inputUsuario = document.getElementById('usuario');
  const hintText     = document.getElementById('roleHintText');

  if (perfil === 'admin') {
    labelUsuario.textContent     = 'Usuário';
    inputUsuario.placeholder     = 'Digite seu usuário';
    hintText.innerHTML           = 'Acesso padrão: <code>admin</code> / <code>admin123</code>';
  } else {
    labelUsuario.textContent     = 'CPF (somente números)';
    inputUsuario.placeholder     = 'Digite seu CPF somente números';
    hintText.innerHTML           = 'Senha padrão: <strong>número do seu imóvel</strong> (ex: 101)';
  }

  esconderErro();
}

async function fazerLogin(e) {
  e.preventDefault();
  setLoading(true);
  esconderErro();

  const usuario = document.getElementById('usuario').value.trim();
  const senha   = document.getElementById('senha').value;

  try {
    const resp = await fetch('/api/auth/login', {
      method:      'POST',
      headers:     { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body:        JSON.stringify({ usuario, senha }),
    });

    const data = await resp.json();

    if (!resp.ok) {
      exibirErro(data.erro || 'Credenciais inválidas.');
    } else {
      window.location.href = data.redirect || '/';
    }
  } catch {
    exibirErro('Não foi possível conectar ao servidor.');
  } finally {
    setLoading(false);
  }
}

function setLoading(on) {
  const btn = document.getElementById('btnLogin');
  document.getElementById('btnText').style.display    = on ? 'none' : '';
  document.getElementById('btnLoading').style.display = on ? '' : 'none';
  btn.disabled = on;
}

function exibirErro(msg) {
  const el = document.getElementById('alertError');
  el.textContent   = msg;
  el.style.display = 'block';
}

function esconderErro() {
  document.getElementById('alertError').style.display = 'none';
}

function toggleSenha() {
  const input  = document.getElementById('senha');
  const eyeOn  = document.getElementById('iconEye');
  const eyeOff = document.getElementById('iconEyeOff');
  const hide   = input.type === 'password';
  input.type          = hide ? 'text' : 'password';
  eyeOn.style.display  = hide ? 'none' : '';
  eyeOff.style.display = hide ? '' : 'none';
}

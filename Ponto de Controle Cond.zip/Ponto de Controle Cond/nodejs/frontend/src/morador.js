/**
 * morador.js — Área do Morador
 * Carrega e exibe os dados do imóvel vinculado à sessão do morador.
 */

const API = 'http://localhost:3000/api';

document.addEventListener('DOMContentLoaded', async () => {
  // Verifica sessão
  try {
    const resp = await fetch('/api/auth/me', { credentials: 'same-origin' });
    if (!resp.ok) { window.location.href = '/login'; return; }
    const user = await resp.json();

    if (user.role === 'admin') { window.location.href = '/'; return; }

    document.getElementById('userName').textContent = user.nome || user.usuario;
    document.getElementById('welcomeName').textContent = `Olá, ${(user.nome || user.usuario).split(' ')[0]}!`;
  } catch {
    window.location.href = '/login';
    return;
  }

  // Carrega imóvel
  await carregarImovel();
});

async function carregarImovel() {
  try {
    const resp = await fetch(`${API}/imoveis`, { credentials: 'same-origin' });
    const data = await resp.json();

    document.getElementById('stateLoading').style.display = 'none';

    if (!data.imoveis || data.imoveis.length === 0) {
      mostrarErro('Nenhum imóvel vinculado à sua conta.');
      return;
    }

    const imovel = data.imoveis[0];
    preencherCard(imovel);
    document.getElementById('stateCard').style.display = 'block';

  } catch {
    document.getElementById('stateLoading').style.display = 'none';
    mostrarErro('Não foi possível conectar ao servidor.');
  }
}

function preencherCard(imovel) {
  const isPadrao = imovel.tipo === 'Casa Padrão';

  document.getElementById('cardBadge').textContent  = isPadrao ? '🏠' : '🏡';
  document.getElementById('cardNumero').textContent = `Imóvel #${imovel.numero}`;
  document.getElementById('cardTipo').textContent   = imovel.tipo;
  document.getElementById('cardTaxa').textContent   = brl(imovel.taxa);

  document.getElementById('dRua').textContent   = imovel.rua;
  document.getElementById('dArea').textContent  = `${imovel.area} m²`;
  document.getElementById('dNome').textContent  = imovel.nomeMorador || '—';
  document.getElementById('dCpf').textContent   = imovel.cpf      || '—';
  document.getElementById('dTel').textContent   = imovel.telefone || '—';
  document.getElementById('dJardinagem').textContent = imovel.jardinagem || '—';

  if (isPadrao) {
    document.getElementById('dGaragem').textContent = imovel.temGaragem ? 'Sim' : 'Não';
    document.getElementById('dGaragemWrap').style.display  = '';
    document.getElementById('dEsquinaWrap').style.display  = 'none';
    document.getElementById('dFrenteWrap').style.display   = 'none';
  } else {
    document.getElementById('dGaragemWrap').style.display  = 'none';
    document.getElementById('dEsquina').textContent        = imovel.ruaSecundaria || '—';
    document.getElementById('dFrente').textContent         = `${imovel.metrosFrente} m`;
    document.getElementById('dEsquinaWrap').style.display  = '';
    document.getElementById('dFrenteWrap').style.display   = '';
  }
}

function mostrarErro(msg) {
  document.getElementById('stateErrorMsg').textContent = msg;
  document.getElementById('stateError').style.display  = 'flex';
}

async function fazerLogout() {
  await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
  window.location.href = '/login';
}

function brl(valor) {
  return (valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

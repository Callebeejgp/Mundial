/**
 * FRONTEND / CLI (Main): Interface de console do Sistema de Gestão de Condomínio.
 * Utiliza readline (equivalente ao Scanner do Java) para capturar entradas do usuário.
 * Estrutura: loop do-while com menu switch/case.
 *
 * Para executar: node Main.js
 */

const readline = require('readline');

// Importações dos módulos do backend (equivalente aos imports Java)
const Financeiro  = require('../../backend/src/service/Financeiro');
const CasaPadrao  = require('../../backend/src/model/CasaPadrao');
const CasaEsquina = require('../../backend/src/model/CasaEsquina');
const Morador     = require('../../backend/src/model/Morador');

// Instância do serviço financeiro (OBJETO criado a partir da CLASSE)
const financeiro = new Financeiro();

// Configuração do readline (equivalente ao Scanner)
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

/** Utilitário: lê uma linha do usuário de forma assíncrona */
function perguntar(pergunta) {
  return new Promise(resolve => rl.question(pergunta, resolve));
}

/** Limpa o console para melhor visualização */
function limparConsole() {
  console.clear();
}

/** Exibe o cabeçalho estilizado do sistema */
function exibirCabecalho() {
  console.log('============================================');
  console.log('   SISTEMA DE GESTÃO DE CONDOMÍNIO - Node  ');
  console.log('============================================');
}

/** Exibe o menu principal */
function exibirMenu() {
  console.log('\n--- MENU PRINCIPAL ---');
  console.log('1. Cadastrar Casa Padrão');
  console.log('2. Cadastrar Casa de Esquina');
  console.log('3. Listar Imóveis e Taxas');
  console.log('4. Ver Saldo Total do Condomínio');
  console.log('5. Sair');
  console.log('----------------------');
}

/**
 * Função: Cadastrar Casa Padrão
 * Lê dados do usuário e cria instância de CasaPadrao (HERANÇA / INSTÂNCIA).
 */
async function cadastrarCasaPadrao() {
  console.log('\n-- Cadastro de Casa Padrão --');

  const numeroStr  = await perguntar('Número do imóvel: ');
  const numero     = parseInt(numeroStr);

  if (isNaN(numero) || numero <= 0) {
    console.log('[ERRO] Número inválido.');
    return;
  }
  if (financeiro.imovelJaCadastrado(numero)) {
    console.log(`[ERRO] Imóvel #${numero} já cadastrado.`);
    return;
  }

  const rua           = await perguntar('Rua: ');
  const areaStr       = await perguntar('Área construída (m²): ');
  const area          = parseFloat(areaStr);
  const garagemStr    = await perguntar('Possui garagem? (s/n): ');
  const temGaragem    = garagemStr.toLowerCase() === 's';

  // Dados do morador
  const nomeMorador   = await perguntar('Nome do morador: ');
  const cpfMorador    = await perguntar('CPF do morador: ');
  const telMorador    = await perguntar('Telefone do morador: ');

  if (isNaN(area) || area <= 0) {
    console.log('[ERRO] Área inválida.');
    return;
  }

  // INSTANCIAÇÃO: criando objetos CasaPadrao e Morador (POO)
  const morador = new Morador(nomeMorador, cpfMorador, telMorador);
  const casa    = new CasaPadrao(numero, rua, area, temGaragem);

  financeiro.cadastrarImovel(casa);

  console.log('\n✔ Casa Padrão cadastrada com sucesso!');
  console.log(casa.toString());
  console.log(morador.toString());

  // INTERFACE: demonstrando realizarJardinagem()
  console.log(casa.realizarJardinagem());
}

/**
 * Função: Cadastrar Casa de Esquina
 * Lê dados e cria instância de CasaEsquina (POLIMORFISMO).
 */
async function cadastrarCasaEsquina() {
  console.log('\n-- Cadastro de Casa de Esquina --');

  const numeroStr    = await perguntar('Número do imóvel: ');
  const numero       = parseInt(numeroStr);

  if (isNaN(numero) || numero <= 0) {
    console.log('[ERRO] Número inválido.');
    return;
  }
  if (financeiro.imovelJaCadastrado(numero)) {
    console.log(`[ERRO] Imóvel #${numero} já cadastrado.`);
    return;
  }

  const rua            = await perguntar('Rua principal: ');
  const ruaSecundaria  = await perguntar('Rua secundária (esquina): ');
  const areaStr        = await perguntar('Área construída (m²): ');
  const area           = parseFloat(areaStr);
  const frenteStr      = await perguntar('Metros de frente total: ');
  const frente         = parseFloat(frenteStr);

  // Dados do morador
  const nomeMorador    = await perguntar('Nome do morador: ');
  const cpfMorador     = await perguntar('CPF do morador: ');
  const telMorador     = await perguntar('Telefone do morador: ');

  if (isNaN(area) || area <= 0 || isNaN(frente) || frente <= 0) {
    console.log('[ERRO] Valores de área ou frente inválidos.');
    return;
  }

  // POLIMORFISMO: CasaEsquina tem calcularTaxaCondominio() diferente
  const morador = new Morador(nomeMorador, cpfMorador, telMorador);
  const casa    = new CasaEsquina(numero, rua, area, ruaSecundaria, frente);

  financeiro.cadastrarImovel(casa);

  console.log('\n✔ Casa de Esquina cadastrada com sucesso!');
  console.log(casa.toString());
  console.log(morador.toString());
  console.log(casa.realizarJardinagem());
}

/**
 * Função: Listar todos os imóveis e suas taxas.
 * POLIMORFISMO: calcularTaxaCondominio() é chamado sem saber o tipo exato.
 */
function listarImoveis() {
  console.log('\n-- Lista de Imóveis Cadastrados --');
  if (financeiro.imoveis.length === 0) {
    console.log('Nenhum imóvel cadastrado ainda.');
    return;
  }
  financeiro.imoveis.forEach((imovel, index) => {
    console.log(`\n[${index + 1}] ${imovel.toString()}`);
  });
}

/**
 * Função: Exibir saldo total arrecadado com as taxas.
 */
function verSaldoTotal() {
  console.log('\n-- Saldo Total do Condomínio --');
  const total = financeiro.calcularSaldoTotal();
  const qtd   = financeiro.totalImoveis();
  console.log(`Total de imóveis: ${qtd}`);
  console.log(`Saldo total (soma das taxas): R$ ${total.toFixed(2)}`);
}

/**
 * FUNÇÃO PRINCIPAL: Loop do-while com switch/case (equivalente ao Java).
 */
async function main() {
  limparConsole();
  exibirCabecalho();

  let opcao = '';

  // LOOP DO-WHILE: continua até o usuário escolher sair
  do {
    exibirMenu();
    opcao = await perguntar('Escolha uma opção: ');

    // SWITCH/CASE: direciona a execução conforme a opção
    switch (opcao.trim()) {
      case '1':
        await cadastrarCasaPadrao();
        break;
      case '2':
        await cadastrarCasaEsquina();
        break;
      case '3':
        listarImoveis();
        break;
      case '4':
        verSaldoTotal();
        break;
      case '5':
        console.log('\nEncerrando o sistema. Até logo!');
        break;
      default:
        console.log('\n[AVISO] Opção inválida. Tente novamente.');
    }

    if (opcao.trim() !== '5') {
      await perguntar('\nPressione ENTER para continuar...');
      limparConsole();
      exibirCabecalho();
    }

  } while (opcao.trim() !== '5');

  rl.close();
}

// Inicia o sistema
main();

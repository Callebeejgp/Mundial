/**
 * SERVICE (POO / Regras de Negócio): Classe Financeiro gerencia as finanças do condomínio.
 * Centraliza o cadastro de imóveis e os cálculos financeiros.
 * Usa um array de objetos Imovel (polimorfismo em ação ao chamar calcularTaxaCondominio).
 */
class Financeiro {
  /**
   * CONSTRUTOR: Inicializa a lista de imóveis vazia.
   */
  constructor() {
    // ENCAPSULAMENTO: lista privada de imóveis cadastrados
    this._imoveis = [];
  }

  /**
   * Cadastra um novo imóvel na lista do condomínio.
   * @param {Imovel} imovel - Instância de CasaPadrao ou CasaEsquina
   */
  cadastrarImovel(imovel) {
    this._imoveis.push(imovel);
  }

  /**
   * Retorna a lista de todos os imóveis cadastrados.
   * @returns {Array} Lista de imóveis
   */
  get imoveis() {
    return this._imoveis;
  }

  /**
   * POLIMORFISMO em uso: Itera sobre imóveis e chama calcularTaxaCondominio(),
   * que se comporta de forma diferente para CasaPadrao e CasaEsquina.
   * @returns {number} Soma total das taxas de condomínio
   */
  calcularSaldoTotal() {
    return this._imoveis.reduce((total, imovel) => {
      return total + imovel.calcularTaxaCondominio(); // Polimorfismo em ação!
    }, 0);
  }

  /**
   * Verifica se já existe imóvel cadastrado com o mesmo número.
   * @param {number} numero - Número do imóvel
   * @returns {boolean}
   */
  imovelJaCadastrado(numero) {
    return this._imoveis.some(i => i.numero === numero);
  }

  /**
   * Retorna a quantidade de imóveis cadastrados.
   * @returns {number}
   */
  totalImoveis() {
    return this._imoveis.length;
  }
}

module.exports = Financeiro;

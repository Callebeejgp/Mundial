/**
 * INTERFACE (POO): Simulação de interface em JavaScript.
 * Define o contrato que qualquer classe "manutenível" deve cumprir.
 * Classes que "implementam" esta interface devem sobrescrever realizarJardinagem().
 */
class Manutencao {
  /**
   * Método que simula o contrato da interface.
   * Lança erro se não for implementado pela subclasse.
   */
  realizarJardinagem() {
    throw new Error(`O método realizarJardinagem() deve ser implementado pela classe: ${this.constructor.name}`);
  }
}

module.exports = Manutencao;

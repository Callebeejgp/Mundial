const Imovel = require('./Imovel');
const Manutencao = require('../interfaces/Manutencao');

/**
 * POLIMORFISMO (POO): CasaEsquina herda de Imovel mas tem cálculo de taxa diferente.
 * Por ser imóvel de esquina, tem maior visibilidade e paga taxa adicional.
 * Taxa: R$300 fixos + R$7,50 por m² + adicional por ter 2 frentes.
 */
class CasaEsquina extends Imovel {
  /**
   * CONSTRUTOR: Inicializa com atributos específicos de imóvel de esquina.
   * @param {number} numero - Número do imóvel
   * @param {string} rua - Rua principal
   * @param {number} areaConstruida - Área em m²
   * @param {string} ruaSecundaria - Rua secundária (frente de esquina)
   * @param {number} metrosFrente - Metros de frente total
   */
  constructor(numero, rua, areaConstruida, ruaSecundaria, metrosFrente = 10) {
    super(numero, rua, areaConstruida); // Chama construtor da classe pai (Imovel)
    this._ruaSecundaria = ruaSecundaria;
    this._metrosFrente = metrosFrente;
    this._tipo = 'Casa de Esquina';
  }

  get ruaSecundaria() { return this._ruaSecundaria; }
  set ruaSecundaria(valor) { this._ruaSecundaria = valor; }

  get metrosFrente() { return this._metrosFrente; }
  set metrosFrente(valor) { this._metrosFrente = valor; }

  get tipo() { return this._tipo; }

  /**
   * POLIMORFISMO: implementação DIFERENTE da CasaPadrao.
   * Taxa maior por ser imóvel de esquina (mais valorizado e com mais frente).
   * @returns {number} Valor da taxa de condomínio
   */
  calcularTaxaCondominio() {
    const taxaBase = 300.00;
    const taxaPorM2 = 7.50;
    const adicionalEsquina = this._metrosFrente * 3.00; // R$3 por metro de frente
    return taxaBase + (this._areaConstruida * taxaPorM2) + adicionalEsquina;
  }

  /**
   * INTERFACE (via mixin Manutencao): Jardinagem mais robusta para esquinas.
   */
  realizarJardinagem() {
    return (
      `[Casa Esquina #${this._numero}] Jardinagem dupla: ` +
      `poda nas ruas ${this._rua} e ${this._ruaSecundaria}.`
    );
  }

  toString() {
    const taxa = this.calcularTaxaCondominio().toFixed(2);
    return (
      `[${this._tipo}] #${this._numero} | Rua: ${this._rua} / ${this._ruaSecundaria} | ` +
      `Área: ${this._areaConstruida}m² | Frente: ${this._metrosFrente}m | Taxa: R$${taxa}`
    );
  }
}

// Mixin para simular "implementação" de interface
Object.assign(CasaEsquina.prototype, Manutencao.prototype);

module.exports = CasaEsquina;

/**
 * CLASSE E OBJETO (POO): Representa um morador do condomínio.
 * ENCAPSULAMENTO: Todos os atributos são privados com getters/setters.
 */
class Morador {
  /**
   * CONSTRUTOR personalizado para inicializar o objeto Morador.
   * @param {string} nome - Nome completo do morador
   * @param {string} cpf - CPF do morador
   * @param {string} telefone - Telefone de contato
   */
  constructor(nome, cpf, telefone) {
    // ENCAPSULAMENTO: atributos privados
    this._nome = nome;
    this._cpf = cpf;
    this._telefone = telefone;
  }

  // --- GETTERS E SETTERS ---

  get nome() { return this._nome; }
  set nome(valor) {
    if (!valor || valor.trim() === '') throw new Error('Nome não pode ser vazio.');
    this._nome = valor;
  }

  get cpf() { return this._cpf; }
  set cpf(valor) { this._cpf = valor; }

  get telefone() { return this._telefone; }
  set telefone(valor) { this._telefone = valor; }

  toString() {
    return `Morador: ${this._nome} | CPF: ${this._cpf} | Tel: ${this._telefone}`;
  }
}

module.exports = Morador;

/**
 * CLASSE ABSTRATA (POO): Imovel não pode ser instanciada diretamente.
 * Serve como base para CasaPadrao e CasaEsquina.
 * HERANÇA: CasaPadrao e CasaEsquina herdam desta classe.
 */
class Imovel {
  /**
   * CONSTRUTOR: Inicializa os atributos comuns a todos os imóveis.
   * ENCAPSULAMENTO: Atributos prefixados com '_' são privados por convenção.
   * @param {number} numero - Número do imóvel
   * @param {string} rua - Rua do imóvel
   * @param {number} areaConstruida - Área em m²
   */
  constructor(numero, rua, areaConstruida) {
    // Impede instanciação direta (abstração)
    if (new.target === Imovel) {
      throw new Error('Imovel é uma classe abstrata e não pode ser instanciada diretamente.');
    }

    // ENCAPSULAMENTO: atributos privados
    this._numero = numero;
    this._rua = rua;
    this._areaConstruida = areaConstruida;
  }

  // --- GETTERS E SETTERS (Encapsulamento) ---

  get numero() { return this._numero; }
  set numero(valor) {
    if (valor <= 0) throw new Error('Número do imóvel deve ser positivo.');
    this._numero = valor;
  }

  get rua() { return this._rua; }
  set rua(valor) { this._rua = valor; }

  get areaConstruida() { return this._areaConstruida; }
  set areaConstruida(valor) {
    if (valor <= 0) throw new Error('Área construída deve ser positiva.');
    this._areaConstruida = valor;
  }

  /**
   * POLIMORFISMO: Método abstrato que DEVE ser sobrescrito pelas subclasses.
   * Cada tipo de imóvel calcula a taxa de forma diferente.
   */
  calcularTaxaCondominio() {
    throw new Error(`calcularTaxaCondominio() deve ser implementado por ${this.constructor.name}`);
  }

  /**
   * Retorna descrição formatada do imóvel.
   */
  toString() {
    return `Imóvel #${this._numero} | Rua: ${this._rua} | Área: ${this._areaConstruida}m²`;
  }
}

module.exports = Imovel;

const Imovel = require('./Imovel');
const Manutencao = require('../interfaces/Manutencao');

/**
 * HERANÇA (POO): CasaPadrao herda de Imovel e "implementa" Manutencao.
 * POLIMORFISMO: Sobrescreve calcularTaxaCondominio() com sua própria lógica.
 * Taxa base: R$ 200,00 + R$ 5,00 por m² de área construída.
 */
class CasaPadrao extends Imovel {
  /**
   * CONSTRUTOR: Chama o construtor pai com super() e adiciona atributos específicos.
   * @param {number} numero - Número do imóvel
   * @param {string} rua - Rua do imóvel
   * @param {number} areaConstruida - Área em m²
   * @param {boolean} temGaragem - Indica se possui garagem
   */
  constructor(numero, rua, areaConstruida, temGaragem = false) {
    super(numero, rua, areaConstruida); // Chama construtor da classe pai (Imovel)
    this._temGaragem = temGaragem;
    this._tipo = 'Casa Padrão';
  }

  get temGaragem() { return this._temGaragem; }
  set temGaragem(valor) { this._temGaragem = valor; }

  get tipo() { return this._tipo; }

  /**
   * POLIMORFISMO: Implementação específica para CasaPadrao.
   * Taxa = R$200 fixos + R$5 por m².
   * @returns {number} Valor da taxa de condomínio
   */
  calcularTaxaCondominio() {
    const taxaBase = 200.00;
    const taxaPorM2 = 5.00;
    const adicionalGaragem = this._temGaragem ? 50.00 : 0.00;
    return taxaBase + (this._areaConstruida * taxaPorM2) + adicionalGaragem;
  }

  /**
   * INTERFACE (via herança de Manutencao): Implementa realizarJardinagem().
   */
  realizarJardinagem() {
    return `[Casa Padrão #${this._numero}] Jardinagem realizada: corte de grama e poda básica.`;
  }

  toString() {
    const taxa = this.calcularTaxaCondominio().toFixed(2);
    const garagem = this._temGaragem ? 'Sim' : 'Não';
    return (
      `[${this._tipo}] #${this._numero} | Rua: ${this._rua} | ` +
      `Área: ${this._areaConstruida}m² | Garagem: ${garagem} | Taxa: R$${taxa}`
    );
  }
}

// Mixin para simular "implementação" de interface
Object.assign(CasaPadrao.prototype, Manutencao.prototype);

module.exports = CasaPadrao;

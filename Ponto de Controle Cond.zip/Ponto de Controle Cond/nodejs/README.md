# 🏘️ CondoGest — Sistema de Gestão de Condomínio

Um sistema acadêmico de **Gestão de Condomínio**, desenvolvido com foco prático em **Programação Orientada a Objetos (POO)**. O projeto evoluiu de uma interface de linha de comando (CLI) para uma aplicação web profissional estilo SaaS (inspirada em ferramentas modernas como Linear e Stripe), completa com sistema de login e persistência de dados.

O sistema permite que um **Administrador** gerencie imóveis (casas padrão e de esquina), visualize dashboards financeiros e emita acessos para os **Moradores**, que por sua vez acessam uma interface restrita para ver os detalhes do próprio imóvel.

---

## 🚀 Tecnologias Integradas

- **Backend / Core:** Node.js (JavaScript puro com ES6 Classes)
- **Servidor Web / API:** Express.js
- **Segurança / Auth:** `express-session` (gerenciamento de sessão), `bcryptjs` (hash de senhas)
- **Frontend UI:** HTML5 semântico, CSS3 (variáveis, flexbox, grid - "Vanilla CSS") e JavaScript Nativo (Vanilla JS). DOM manipulations nativas (sem React/Vue/Angular).
- **Persistência de Dados (DB):** Sistema em arquivos JSON (`dados.json` para os imóveis, e `usuarios.json` para senhas via fs do Node).

---

## 🧠 Conceitos de Banco de Dados e POO Aplicados

A espinha dorsal em `backend/src/` foi escrita 100% sobre as bases de **Programação Orientada a Objetos**, utilizando a sintaxe do JavaScript (ES6+):

1. **Abstração:**
   - A classe abstrata `Imovel.js` isola as propriedades e ações fundamentais necessárias para todo tipo de imóvel. O Node impede sua instanciação direta jogando erros em seu construtor.
2. **Herança:**
   - As classes `CasaPadrao` e `CasaEsquina` **herdam** (`extends Imovel`) de `Imovel`, herdando atributos como área, número, rua, além de expandirem características próprias.
3. **Encapsulamento:**
   - Usado amplamente (simulado através de convenções como `_atributo` nos setters e getters). Regras de negócios são blindadas, modificáveis estritamente passando pelos validadores das classes.
4. **Polimorfismo:**
   - Método `calcularTaxaCondominio()` tem uma base na classe mãe, e é sobrescrito nas subclasses para se comportar com cálculos diferentes:
     - *Casa Padrão:* Soma taxa base (R$ 200) + multiplicador de M² + Taxa extra caso tenha garagem.
     - *Casa Esquina:* Soma taxa base (R$ 300) + multiplicador M² + taxa baseada nos metros de fachada secundária.
5. **Interface (Contrato):**
   - Utilizado o padrão de simulação de interface (Mixins) onde `CasaEsquina` implementa contratos (ex: interface de `Manutencao` para limpeza pesada / jardinagem externa).

---

## 🛠️ Funcionalidades e Perfis

### ✨ Perfil: Administrador (Gerente)
O Administrador tem visão total do condomínio.
* **Painel de Dashboard:** Visualiza total de imóveis cadastrados, separados por tipos, e saldo estimado da arrecadação mensal em tempo real.
* **Tabela Geral:** Relatório listando com filtros todos imóveis e acesso a todos os detalhes (inclusive atributos específicos como garagens e medidas).
* **Cadastro Dinâmico de Imóveis (Formulário):**
  * Escolha de tipo visual e intuitiva (alternando campos do form).
  * Inputs para dados pessoais e CPF do morador.
  * **Criação Automática de Acesso:** O sistema, no momento em que finaliza o cadastro do imóvel, gera ou vincula senhas do morador (por padrão usando o número ou um gerador aleatório da tela).
  * Exibição de Modal central confirmando o Login/Senha criados.

### ✨ Perfil: Morador (Restrito)
Para testar, basta usar o login e senha gerados pelo painel do Admin.
* Redirecionado para uma tela leve (`morador.html`).
* Ele visualiza exclusivamente o painel em forma de "Card" do respectivo imóvel associado.
* Informações sobre a sua classe específica e a taxa mensal cobrada a ele.

---

## 📂 Arquitetura do Projeto

```text
nodejs/
├── backend/                  # Núcleo isolado das regras de negócios
│   └── src/
│       ├── model/            # Modelos reais do banco (POO)
│       │   ├── Imovel.js
│       │   ├── CasaPadrao.js
│       │   ├── CasaEsquina.js
│       │   └── Morador.js
│       ├── interfaces/       # Definição de contratos
│       │   └── Manutencao.js
│       └── service/          # Gerência do motor em runtime
│           └── Financeiro.js
│
├── frontend/                 # UI Profissional Web
│   └── src/
│       ├── index.html        # SPA / Dashboard do Admin
│       ├── style.css         # Design System moderno em blocos
│       ├── app.js            # Lógica cliente-servidor API do Admin
│       ├── login.html        # UI para perfis
│       ├── login.css
│       ├── login.js
│       ├── morador.html      # UI exclusiva para morador
│       ├── morador.css
│       └── morador.js
│
├── dados.json                # Persistência gerada pela API do status dos imovéis
├── usuarios.json             # DB auto-gerado que abriga hashes de senha de login
├── server.js                 # API do Express (Controller do fluxo REST e Auth)
└── package.json              # Dependências do Node NPM
```

---

## ⚙️ Como Instalar e Rodar o Sistema

### Pré-requisitos
* Ter o [Node.js](https://nodejs.org/) instalado em sua máquina.

### Executando em Terminais do Windows, Mac ou Linux

1. Dentro da pasta `nodejs`, assegure que suas dependências base as quais controlam seção Web de Auth estão intocadas. Instale as bibliotecas usando:
   ```bash
   npm install
   ```

2. Execute de forma permanente o servidor com o express:
   ```bash
   node server.js
   ```

3. Abra em qualquer navegador local:
   **`http://localhost:3000/`**

### Credenciais Locais (Primeiras instruções)

O sistema auto-injeta seu primeiro perfil no `usuarios.json`.
* **Usuário Admin:** `admin`
* **Senha Admin:** `admin123`

Para usar o papel (Role) do Morador recém-cadastrado no formulário:
* **Usuário:** *[CPF usado no morador, formatado apenas em números]*
* **Senha:** *[Número da Casa (gerada por padrão) ou a do Botão "Gerar"]*

---

## 📄 Termos de Uso (Arquitetura)

Qualquer comunicação no Backend (`server.js`) é gerenciada pela tecnologia **RESTful.** Modificar a porta requer que modifique a const `API` contida no top line da UI web de Admin e Morador simultaneamente. As rotas internas da UI estão protegidas por uma verificação forte de sessão interceptando o roteamento global via Express.

*Desenvolvido como projeto educacional. Estética profissionalmente adaptada para padrões Clean e Web 3.0 por Inteligência Artificial (Modelo DeepMind Antigravity).*

/**
 * Servidor Express — Sistema de Gestão de Condomínio
 * Autenticação com roles: admin (acesso total) | morador (só seu imóvel)
 * Persistência: dados.json (imóveis) | usuarios.json (usuários)
 */

const express  = require('express');
const cors     = require('cors');
const path     = require('path');
const fs       = require('fs');
const session  = require('express-session');
const bcrypt   = require('bcryptjs');

const Financeiro  = require('./backend/src/service/Financeiro');
const CasaPadrao  = require('./backend/src/model/CasaPadrao');
const CasaEsquina = require('./backend/src/model/CasaEsquina');
const Morador     = require('./backend/src/model/Morador');

const app        = express();
const PORT       = 3000;
const DB_PATH    = path.join(__dirname, 'dados.json');
const USERS_PATH = path.join(__dirname, 'usuarios.json');
const STATIC_DIR = path.join(__dirname, 'frontend', 'src');

// ──────────────────────────────────────────────────────
//  USUÁRIOS
// ──────────────────────────────────────────────────────

function inicializarUsuarios() {
  if (!fs.existsSync(USERS_PATH)) {
    const senhaHash = bcrypt.hashSync('admin123', 10);
    const usuarios  = [{
      usuario: 'admin',
      senha:   senhaHash,
      nome:    'Administrador',
      role:    'admin',        // admin | morador
      numeroImovel: null,
    }];
    fs.writeFileSync(USERS_PATH, JSON.stringify(usuarios, null, 2), 'utf-8');
    console.log('👤  Usuário padrão criado: admin / admin123');
  }
}

function lerUsuarios() {
  try { return JSON.parse(fs.readFileSync(USERS_PATH, 'utf-8')); }
  catch { return []; }
}

function salvarUsuarios(usuarios) {
  fs.writeFileSync(USERS_PATH, JSON.stringify(usuarios, null, 2), 'utf-8');
}

/**
 * Cria automaticamente a conta do morador ao cadastrar um imóvel.
 * Login: CPF (apenas dígitos)
 * Senha padrão: número do imóvel (ex: "101")
 */
function criarContaMorador(cpf, nomeMorador, numeroImovel, loginCustom, senhaCustom) {
  const usuarios   = lerUsuarios();
  
  const usuarioTexto = loginCustom ? loginCustom.trim() : cpf.replace(/\D/g, '');
  const senhaTexto   = senhaCustom ? senhaCustom : String(numeroImovel);

  // Não recria se já existir
  if (usuarios.some(u => u.usuario === usuarioTexto)) return;

  const hash = bcrypt.hashSync(senhaTexto, 10);

  usuarios.push({
    usuario:     usuarioTexto,
    senha:       hash,
    nome:        nomeMorador,
    role:        'morador',
    numeroImovel: Number(numeroImovel),
  });

  salvarUsuarios(usuarios);
  console.log(`👤  Conta morador criada: ${usuarioTexto} / ${senhaTexto} (nº ${numeroImovel})`);
}

// ──────────────────────────────────────────────────────
//  PERSISTÊNCIA: imóveis
// ──────────────────────────────────────────────────────

function carregarDados() {
  const financeiro = new Financeiro();
  const moradores  = new Map();

  if (!fs.existsSync(DB_PATH)) {
    console.log('📂  Nenhum dado salvo. Iniciando vazio.');
    return { financeiro, moradores };
  }

  try {
    const dados = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    for (const r of dados) {
      const casa = r.tipo === 'Casa Padrão'
        ? new CasaPadrao(r.numero, r.rua, r.area, r.temGaragem)
        : new CasaEsquina(r.numero, r.rua, r.area, r.ruaSecundaria, r.metrosFrente);
      financeiro.cadastrarImovel(casa);
      moradores.set(r.numero, new Morador(r.morador.nome, r.morador.cpf, r.morador.telefone));
    }
    console.log(`📂  ${dados.length} registro(s) carregado(s) de dados.json`);
  } catch (err) {
    console.error('⚠️  Erro ao ler dados.json:', err.message);
  }

  return { financeiro, moradores };
}

function salvarDados(financeiro, moradores) {
  const registros = financeiro.imoveis.map(imovel => {
    const m = moradores.get(imovel.numero);
    const base = {
      tipo: imovel.tipo, numero: imovel.numero,
      rua: imovel.rua,   area: imovel.areaConstruida,
      morador: { nome: m?.nome || '', cpf: m?.cpf || '', telefone: m?.telefone || '' },
    };
    if (imovel.tipo === 'Casa Padrão') base.temGaragem = imovel.temGaragem;
    else { base.ruaSecundaria = imovel.ruaSecundaria; base.metrosFrente = imovel.metrosFrente; }
    return base;
  });
  fs.writeFileSync(DB_PATH, JSON.stringify(registros, null, 2), 'utf-8');
}

// ──────────────────────────────────────────────────────
//  INICIALIZAÇÃO
// ──────────────────────────────────────────────────────
inicializarUsuarios();
const { financeiro, moradores } = carregarDados();

// ──────────────────────────────────────────────────────
//  MIDDLEWARES
// ──────────────────────────────────────────────────────
app.use(cors({ credentials: true, origin: `http://localhost:${PORT}` }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'condogest-secret-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 8 * 60 * 60 * 1000 },
}));

// Middleware de autenticação e proteção de rotas
app.use((req, res, next) => {
  const PUBLIC = ['/login', '/login.html', '/login.css', '/login.js',
                  '/morador.html', '/morador.css', '/morador.js'];
  const isPublic  = PUBLIC.some(p => req.path.startsWith(p));
  const isApiAuth = req.path.startsWith('/api/auth');
  const isApi     = req.path.startsWith('/api/');

  if (isPublic || isApiAuth) return next();

  if (!req.session.usuario) {
    return isApi
      ? res.status(401).json({ erro: 'Não autenticado.' })
      : res.redirect('/login');
  }

  // Morador só acessa páginas de morador
  if (req.session.usuario.role === 'morador' && !isApi) {
    if (req.path !== '/morador' && req.path !== '/') return next();
  }

  next();
});

app.use(express.static(STATIC_DIR));

// ──────────────────────────────────────────────────────
//  ROTAS DE AUTENTICAÇÃO
// ──────────────────────────────────────────────────────

app.get('/login', (req, res) => {
  if (req.session.usuario) {
    return req.session.usuario.role === 'admin'
      ? res.redirect('/')
      : res.redirect('/morador');
  }
  res.sendFile(path.join(STATIC_DIR, 'login.html'));
});

app.get('/morador', (req, res) => {
  if (!req.session.usuario) return res.redirect('/login');
  if (req.session.usuario.role === 'admin') return res.redirect('/');
  res.sendFile(path.join(STATIC_DIR, 'morador.html'));
});

app.post('/api/auth/login', (req, res) => {
  const { usuario, senha } = req.body;
  const usuarios = lerUsuarios();
  const user     = usuarios.find(u => u.usuario === usuario);

  if (!user || !bcrypt.compareSync(senha, user.senha)) {
    return res.status(401).json({ erro: 'Usuário ou senha incorretos.' });
  }

  req.session.usuario = {
    usuario:     user.usuario,
    nome:        user.nome,
    role:        user.role || 'admin',
    numeroImovel: user.numeroImovel || null,
  };

  res.json({
    ok:          true,
    nome:        user.nome,
    role:        user.role || 'admin',
    redirect:    user.role === 'morador' ? '/morador' : '/',
  });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/auth/me', (req, res) => {
  if (!req.session.usuario) return res.status(401).json({ erro: 'Não autenticado.' });
  res.json(req.session.usuario);
});

// ──────────────────────────────────────────────────────
//  HELPER: serializa um imóvel para JSON de resposta
// ──────────────────────────────────────────────────────
function serializarImovel(imovel, moradores) {
  const m = moradores.get(imovel.numero);
  return {
    numero:     imovel.numero,
    tipo:       imovel.tipo,
    rua:        imovel.rua,
    area:       imovel.areaConstruida,
    taxa:       imovel.calcularTaxaCondominio(),
    jardinagem: imovel.realizarJardinagem(),
    morador:    m ? m.toString() : 'Sem morador cadastrado',
    nomeMorador: m?.nome || '',
    cpf:        m?.cpf  || '',
    telefone:   m?.telefone || '',
    ...(imovel.tipo === 'Casa Padrão'     && { temGaragem:    imovel.temGaragem }),
    ...(imovel.tipo === 'Casa de Esquina' && {
      ruaSecundaria: imovel.ruaSecundaria,
      metrosFrente:  imovel.metrosFrente,
    }),
  };
}

// ──────────────────────────────────────────────────────
//  ROTAS DA API
// ──────────────────────────────────────────────────────

// GET /api/imoveis — Admin vê todos; morador vê só o seu
app.get('/api/imoveis', (req, res) => {
  const user = req.session.usuario;

  if (user.role === 'morador') {
    const imovel = financeiro.imoveis.find(i => i.numero === user.numeroImovel);
    if (!imovel) return res.json({ imoveis: [], total: 0 });
    return res.json({ imoveis: [serializarImovel(imovel, moradores)], total: 1 });
  }

  const lista = financeiro.imoveis.map(i => serializarImovel(i, moradores));
  res.json({ imoveis: lista, total: financeiro.totalImoveis() });
});

// GET /api/saldo — Apenas admin
app.get('/api/saldo', (req, res) => {
  if (req.session.usuario?.role !== 'admin') {
    return res.status(403).json({ erro: 'Acesso restrito.' });
  }
  res.json({ saldo: financeiro.calcularSaldoTotal(), totalImoveis: financeiro.totalImoveis() });
});

// POST /api/casas/padrao — Apenas admin
app.post('/api/casas/padrao', (req, res) => {
  if (req.session.usuario?.role !== 'admin')
    return res.status(403).json({ erro: 'Apenas administradores podem cadastrar imóveis.' });

  try {
    const { numero, rua, area, temGaragem, nomeMorador, cpf, telefone, loginMorador, senhaMorador } = req.body;
    if (financeiro.imovelJaCadastrado(numero))
      return res.status(409).json({ erro: `Imóvel #${numero} já cadastrado.` });

    const casa    = new CasaPadrao(Number(numero), rua, Number(area), Boolean(temGaragem));
    const morador = new Morador(nomeMorador, cpf, telefone);
    financeiro.cadastrarImovel(casa);
    moradores.set(Number(numero), morador);
    salvarDados(financeiro, moradores);

    // 👤 Cria conta do morador automaticamente (usando credenciais do form ou padrão)
    criarContaMorador(cpf, nomeMorador, numero, loginMorador, senhaMorador);

    res.status(201).json({
      mensagem: 'Casa Padrão cadastrada!',
      imovel: casa.toString(), morador: morador.toString(),
      taxa: casa.calcularTaxaCondominio(),
      loginMorador: { 
        usuario: loginMorador ? loginMorador.trim() : cpf.replace(/\D/g, ''), 
        senha: senhaMorador || String(numero) 
      },
    });
  } catch (err) { res.status(400).json({ erro: err.message }); }
});

// POST /api/casas/esquina — Apenas admin
app.post('/api/casas/esquina', (req, res) => {
  if (req.session.usuario?.role !== 'admin')
    return res.status(403).json({ erro: 'Apenas administradores podem cadastrar imóveis.' });

  try {
    const { numero, rua, area, ruaSecundaria, metrosFrente, nomeMorador, cpf, telefone, loginMorador, senhaMorador } = req.body;
    if (financeiro.imovelJaCadastrado(numero))
      return res.status(409).json({ erro: `Imóvel #${numero} já cadastrado.` });

    const casa    = new CasaEsquina(Number(numero), rua, Number(area), ruaSecundaria, Number(metrosFrente));
    const morador = new Morador(nomeMorador, cpf, telefone);
    financeiro.cadastrarImovel(casa);
    moradores.set(Number(numero), morador);
    salvarDados(financeiro, moradores);

    // 👤 Cria conta do morador automaticamente
    criarContaMorador(cpf, nomeMorador, numero, loginMorador, senhaMorador);

    res.status(201).json({
      mensagem: 'Casa de Esquina cadastrada!',
      imovel: casa.toString(), morador: morador.toString(),
      taxa: casa.calcularTaxaCondominio(),
      loginMorador: { 
        usuario: loginMorador ? loginMorador.trim() : cpf.replace(/\D/g, ''), 
        senha: senhaMorador || String(numero) 
      },
    });
  } catch (err) { res.status(400).json({ erro: err.message }); }
});

// ──────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🏘️  CondoGest`);
  console.log(`✅  Servidor: http://localhost:${PORT}`);
  console.log(`💾  Dados:    ${DB_PATH}`);
  console.log(`👤  Usuários: ${USERS_PATH}\n`);
});
